<?php
function philosophy_demo_import_files() {
    return [
      [
        'import_file_name'             => 'Demo Import 1',
        'categories'                   => [ 'Category 1', 'Category 2' ],
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-content/philosophy-content.xml',
        'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-content/philosophy-widgets.wie',
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-content/philosophy-customizer.dat',
        'import_preview_image_url'     => 'http://localhost/wp/widget/wp-content/themes/philosophy/inc/demo-content/demo1.png',
        'preview_url'                  => 'http://localhost/wp/widget/',
      ],
       [
        'import_file_name'             => 'Demo Import 2',
        'categories'                   => [ 'Category 1', 'Category 2' ],
        'local_import_file'            => trailingslashit( get_template_directory() ) . 'inc/demo-content/philosophy-content.xml',
        'local_import_widget_file'     => trailingslashit( get_template_directory() ) . 'inc/demo-content/philosophy-widgets.wie',
        'local_import_customizer_file' => trailingslashit( get_template_directory() ) . 'inc/demo-content/philosophy-customizer.dat',
        'import_preview_image_url'     => 'http://localhost/wp/widget/wp-content/themes/philosophy/inc/demo-content/demo1.png',
        'preview_url'                  => 'http://localhost/wp/widget/',

      ],
    ];
  }
  add_filter( 'ocdi/import_files', 'philosophy_demo_import_files' );