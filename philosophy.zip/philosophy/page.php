
<?php get_header(); ?>

    <!-- s-content
    ================================================== -->
    <section class="s-content">
        
        <?php the_content(); ?>

    </section> <!-- s-content -->

<?php get_footer() ?>